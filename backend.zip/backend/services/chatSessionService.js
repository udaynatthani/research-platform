const prisma = require("../config/prisma");

/**
 * Chat Session Service
 * Manages persistence of AI chat sessions and messages.
 */

const createSession = async (userId, paperId = null) => {
  return prisma.aIChatSession.create({
    data: {
      userId,
      paperId,
    },
  });
};

const getSessionsByUser = async (userId) => {
  return prisma.aIChatSession.findMany({
    where: { userId },
    include: {
      paper: {
        select: { title: true },
      },
    },
    orderBy: { createdAt: "desc" },
  });
};

const getSessionMessages = async (sessionId) => {
  return prisma.aIChatMessage.findMany({
    where: { sessionId },
    orderBy: { createdAt: "asc" },
  });
};

const addMessage = async (sessionId, role, content) => {
  return prisma.aIChatMessage.create({
    data: {
      sessionId,
      role, // 'user' or 'ai'
      content,
    },
  });
};

module.exports = {
  createSession,
  getSessionsByUser,
  getSessionMessages,
  addMessage,
};
