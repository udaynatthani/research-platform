const linkRepository = require("../repositories/linkRepository");

const createLink = async (data) => {
  const { sourceNodeId, targetNodeId, relationshipType } = data;

  if (!sourceNodeId || !targetNodeId || !relationshipType) {
    throw new Error("sourceNodeId, targetNodeId, and relationshipType are required");
  }

  return linkRepository.createLink(data);
};

const getLinksByProject = async (projectId) => {
  if (!projectId) {
    throw new Error("projectId is required");
  }

  return linkRepository.getLinksByProject(projectId);
};

const deleteLink = async (id) => {
  return linkRepository.deleteLink(id);
};

module.exports = {
  createLink,
  getLinksByProject,
  deleteLink
};