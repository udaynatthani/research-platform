const prisma = require("../config/prisma");

const createLink = async (data) => {
  const { sourceNodeId, targetNodeId, relationshipType } = data;

  return prisma.conceptLink.create({
    data: {
      sourceNodeId,
      targetNodeId,
      relationshipType
    }
  });
};

const getLinksByProject = async (projectId) => {
  return prisma.conceptLink.findMany({
    where: {
      sourceNode: { projectId }
    },
    include: {
      sourceNode: true,
      targetNode: true
    }
  });
};

const deleteLink = async (id) => {
  return prisma.conceptLink.delete({
    where: { id }
  });
};

module.exports = {
  createLink,
  getLinksByProject,
  deleteLink
};